from django.contrib.auth.decorators import user_passes_test
from django.contrib.auth import REDIRECT_FIELD_NAME

def raise_404(method):
	def wrap(*args, **kwargs):
		from django.core.exceptions import ObjectDoesNotExist
		from django.http import Http404
		try:
			return method(*args, **kwargs)
		except ObjectDoesNotExist, ex:
			raise Http404(ex.message)
	return wrap

def is_staff(function=None, redirect_field_name=REDIRECT_FIELD_NAME):
	"""
	Decorator for views that checks that the user is staff, redirecting
	to the log-in page if necessary.
	Possible usage:
	@is_staff
	def view....
	
	urlpatterns = patterns('',
		(r'^databrowse/(.*)', is_staff(databrowse.site.root)),
	)
	"""
	actual_decorator = user_passes_test(
		lambda u: u.is_staff,
		redirect_field_name=redirect_field_name
	)
	if function:
		return actual_decorator(function)
	return actual_decorator