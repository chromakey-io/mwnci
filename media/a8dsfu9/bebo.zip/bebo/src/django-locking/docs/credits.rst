==================
About this project
==================

License
-------

``django-locking`` is released under a simplified BSD license, with the exception of two bits of included software: 

* jQuery, which is dual-licensed (GPL and MIT)
* the jQuery URL Parser which also has an MIT-like license
* icons by Mark James (thanks, Mark!) that are CC-licensed (Attribution 2.5)

Essentially, these licenses allow you to use the software and its constituent parts for any purpose you can think of. Read up on the BSD and MIT licenses if you're interested in the nitty-gritty details and legalese.

Credits
-------

``django-locking`` relies on icons from Mark James. Thanks, Mark! Check out http://www.famfamfam.com. It also makes use of the excellent jQuery library and the jQuery URL Parser.