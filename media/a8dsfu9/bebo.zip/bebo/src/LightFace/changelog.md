LightFace
=========

The following changes have been made to LightFace.


11/17/2010
----------
	+ Updated destroy() method to remove reference to node so that videos stop playing when destroy() is called.
	+ Tag updated from .94 to .96