<?php 
	sleep(1);
	echo 'Hello '.$_POST['name']; 
?>