window.addEvent('domready', function() {
    $$('.ban-text').addEvent('hover',
        function(event){
           event.preventDefault();
        });
    $$('.ban-text').addEvent('click',
        function(event){
            event.preventDefault();
     });
    $$('.ban-button').addEvent('click',
       function(event){
       if (this.get('rel')=='approved'){
         this.set('rel', 'banned');
         this.toggleClass('banned');
         this.getChildren('.ban-text')[0].set('html', 'Banned');
         this.getChildren('fieldset input[type="checkbox"')[0].checked = true;
       }else{
           this.set('rel', 'approved');
           this.toggleClass('banned');
           this.getChildren('.ban-text')[0].set('html', 'Approved');
           this.getChildren('fieldset input[type="checkbox"')[0].checked = false;
      }
    });
    
    $$('.ban-text, .result').addEvent('selectstart',
        function(event){
            event.preventDefault();
    });
});
